# Personal profile website

## Open it
1. Extract this folder.
2. Open `index.html` in a browser.
3. For publishing, upload the whole folder to GitHub Pages or another static host.

## Personalize it
- Replace `images/profile-placeholder.svg` with your photo and update the image path in `index.html` if needed.
- Replace every `Your Name` and edit the bio and interests in `index.html` and `about.html`.
- Add your WhatsApp Channel URL in `contact.html` (replace the placeholder block with an anchor link).
- Your email request form opens the visitor's email app using `mailto:`; it does not send silently.

## Games and chat
The runner mini-game runs in the browser and stores a best score locally. The adjacent note box is private to that visitor's browser, not a live multi-user chat. A real live chat requires a backend or a chat service.
